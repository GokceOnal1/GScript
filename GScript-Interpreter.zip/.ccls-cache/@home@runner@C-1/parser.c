#include "parser.h"
#include <stdio.h>
#include <string.h>

/* This works by basically constructing a tree (called Abstract Syntax Tree or
 * AST) of values and operators for the Interpreter to interpret in the future.
 * The parser makes nodes in the tree by reading (or 'parsing') tokens that have
 * been lexed by the Lexer. */

/*Constructs a Parser based on the LEXER*/
Parser *parser_init(Lexer *lexer) {
  Parser *parser = calloc(1, sizeof(Parser));
  parser->lexer = lexer;
  parser->current_token = lexer_get_next_token(lexer);
  parser->previous_token = parser->current_token;
  return parser;
}
/*Tells the PARSER what TOKEN_TYPE to expect from the lexer. Kind of like
 * lexer_advance()*/
void parser_eat(Parser *parser, int token_type) {
  if (parser->current_token->type == token_type) {
    parser->previous_token = parser->current_token;
    parser->current_token = lexer_get_next_token(parser->lexer);
  } else {
    printf("Internal Error: Unexpected token '%s', with internal type '%d'\n",
           parser->current_token->value, parser->current_token->type);
    exit(1);
  }
}
/*Parses the next statement or statements from the lexer and returns AST Node
 * with value*/
AST *parser_parse(Parser *parser) { return parser_parse_statements(parser); }
/*Parses next statement from the lexer*/
AST *parser_parse_statement(Parser *parser) {
  switch (parser->current_token->type) {
  case T_ID:
    return parser_parse_id(parser);
  }
  return ast_init(AST_NOOP);
}
/*Parses next multiple statements from the lexer and returns AST Node with
 * compound of statements*/
AST *parser_parse_statements(Parser *parser) {
  AST *compound = ast_init(AST_COMPOUND);
  compound->compound_value = calloc(1, sizeof(AST **));

  AST *ast_statement = parser_parse_statement(parser);
  compound->compound_value[0] = ast_statement;
  compound->compound_size++;

  while (parser->current_token->type == T_SEMI) {
    parser_eat(parser, T_SEMI);

    AST *ast_statement = parser_parse_statement(parser);
    if (ast_statement) {
      compound->compound_size++;
      compound->compound_value = realloc(
          compound->compound_value, compound->compound_size * sizeof(AST *));
      compound->compound_value[compound->compound_size - 1] = ast_statement;
    }
  }
  return compound;
}
/*Parses an expression from the lexer and returns AST Node with value of
 * expression*/
AST *parser_parse_expr(Parser *parser) {
  switch (parser->current_token->type) {
  case T_STR:
    return parser_parse_string(parser);
  case T_ID:
    return parser_parse_id(parser);
  }
  return ast_init(AST_NOOP);
}
AST *parser_parse_factor(Parser *parser) {}
AST *parser_parse_term(Parser *parser) {}
/*Parses a function call from the lexer and returns AST Node with relevant
 * information about the function*/
AST *parser_parse_function_call(Parser *parser) {
  AST *function_call = ast_init(AST_FUNC_CALL);
  function_call->func_call_name = parser->previous_token->value;
  parser_eat(parser, T_LPR);
  function_call->func_call_args = calloc(1, sizeof(AST **));

  AST *ast_expr = parser_parse_expr(parser);
  function_call->func_call_args[0] = ast_expr;
  function_call->func_call_args_size++;

  while (parser->current_token->type == T_COMMA) {
    parser_eat(parser, T_COMMA);

    AST *ast_expr = parser_parse_expr(parser);
    function_call->func_call_args_size++;
    function_call->func_call_args =
        realloc(function_call->func_call_args,
                function_call->func_call_args_size * sizeof(AST *));
    function_call->func_call_args[function_call->func_call_args_size - 1] =
        ast_expr;
  }
  parser_eat(parser, T_RPR);
  return function_call;
}
/*Parses a variable reference from the lexer and returns AST Node with relevant
 * information*/
AST *parser_parse_variable(Parser *parser) {
  char *token_value = parser->current_token->value;
  parser_eat(parser, T_ID); // Either var name, or func call name
  if (parser->current_token->type == T_LPR) {
    return parser_parse_function_call(parser);
  }
  AST *ast_var = ast_init(AST_VAR);
  ast_var->var_name = token_value;
  return ast_var;
}
/*Parses a string from the lexer and returns AST Node with relevant
 * information*/
AST *parser_parse_string(Parser *parser) {
  AST *ast_str = ast_init(AST_STR);
  ast_str->str_value = parser->current_token->value;
  parser_eat(parser, T_STR);
  return ast_str;
}
/*Parses an identifier from the lexer and returns AST Node with relevant
 * information*/
AST *parser_parse_id(Parser *parser) {
  if (strcmp(parser->current_token->value, "assign") == 0) {
    return parser_parse_variable_definition(parser);
  } else if (strcmp(parser->current_token->value, "funct") == 0) {
    return parser_parse_function_definition(parser);
  } else {
    return parser_parse_variable(parser);
  }
}
/*Parses a variable definition from the lexer and returns AST Node with relevant
 * information*/
AST *parser_parse_variable_definition(Parser *parser) {
  parser_eat(parser, T_ID);
  char *var_name = parser->current_token->value;
  parser_eat(parser, T_ID);
  parser_eat(parser, T_EQL);
  AST *var_value = parser_parse_expr(parser);
  AST *var_def = ast_init(AST_VAR_DEF);
  var_def->var_def_var_name = var_name;
  var_def->var_def_value = var_value;
  return var_def;
}
/*Parses a function defition from the lexer and returns AST Node with relevant
 * information*/
AST *parser_parse_function_definition(Parser *parser) {
  AST *ast = ast_init(AST_FUNC_DEF);
  parser_eat(parser, T_ID);
  char *func_name = parser->current_token->value;
  parser_eat(parser, T_ID);
  parser_eat(parser, T_LPR);
  parser_eat(parser, T_RPR);
  parser_eat(parser, T_LBR);
  ast->func_def_body = parser_parse_statements(parser);
  parser_eat(parser, T_RBR);
  return ast;
}