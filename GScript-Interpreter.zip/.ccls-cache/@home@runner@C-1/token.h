#ifndef TOKEN_H
#define TOKEN_H
typedef struct token_s {
	enum { T_ID, T_EQL, T_STR, T_SEMI, T_LPR, T_RPR, T_LBR, T_RBR, T_CMT, T_COMMA, T_EOF } type;
	char* value;
} Token;

Token* token_init(int type, char* value); //Token constructor
#endif