#include "visitor.h"
#include <stdio.h>
#include <string.h>

/*(Standard GScript Library Function) Prints ARGV to console */
static AST *std_func_write(Visitor *visitor, AST **argv, int argc) {
  for (int i = 0; i < argc; i++) {
    AST *visited_ast = visitor_visit(visitor, argv[i]);
    switch (visited_ast->type) {
    case AST_STR:
      printf("%s", visited_ast->str_value);
      break;
    }
  }
  printf("\n");
  return ast_init(AST_NOOP);
}
/*(Standard GScript Library Function) Reads next string input from console and
 * returns AST node with it*/
static AST *std_func_read(Visitor *visitor, AST **argv, int argc) {
  if (argc != 1) {
    printf(RED
           "ERR " YEL
           "standard function 'read' only accepts 1 argument but %d were given",
           argc);
    return ast_init(AST_NOOP);
  } else {
    AST *visited_ast = visitor_visit(visitor, argv[0]);
    switch (visited_ast->type) {
    case AST_STR: {
      printf("%s", visited_ast->str_value);
      char *result = malloc(sizeof(char *));
      fgets(result, 1000, stdin);
      if ((strlen(result) > 0) && (result[strlen(result) - 1] == '\n'))
        result[strlen(result) - 1] = '\0';
      AST *uinput_ast = ast_init(AST_STR);
      uinput_ast->str_value = result;
      return uinput_ast;
    }
    }
  }
}
/*Constructs a new visitor*/
Visitor *visitor_init() {
  Visitor *visitor = calloc(1, sizeof(Visitor));
  visitor->var_defs = (void *)0;
  visitor->var_defs_size = 0;
  return visitor;
}
/*Tells the visitor to visit a syntax tree node*/
AST *visitor_visit(Visitor *visitor, AST *node) {
  switch (node->type) {
  case AST_VAR_DEF:
    return visitor_visit_var_def(visitor, node);
    break;
  case AST_FUNC_DEF:
    return visitor_visit_func_def(visitor, node);
    break;
  case AST_VAR:
    return visitor_visit_var(visitor, node);
    break;
  case AST_FUNC_CALL:
    return visitor_visit_func_call(visitor, node);
    break;
  case AST_STR:
    return visitor_visit_str(visitor, node);
    break;
  case AST_COMPOUND:
    return visitor_visit_compound(visitor, node);
    break;
  case AST_NOOP:
    return node;
    break;
  }
  printf("Uncaught statement of type '%d'\n", node->type);
  exit(1);
  return ast_init(AST_NOOP);
}
/*Tells the visitor to interpret a variable definition and store it to memory*/
AST *visitor_visit_var_def(Visitor *visitor, AST *node) {

  if (visitor->var_defs == (void *)0) {
    visitor->var_defs = calloc(1, sizeof(AST *));
    visitor->var_defs[0] = node;
    visitor->var_defs_size++;
  } else {
    visitor->var_defs_size++;
    visitor->var_defs =
        realloc(visitor->var_defs, visitor->var_defs_size * sizeof(AST *));
    visitor->var_defs[visitor->var_defs_size - 1] = node;
  }
  return node;
}
AST* visitor_visit_func_def(Visitor *visitor, AST* node) {

}
/*Tells the visitor to interpret a variable value and store it to memory*/
AST *visitor_visit_var(Visitor *visitor, AST *node) {
  for (int i = 0; i < visitor->var_defs_size; i++) {
    AST *vardef = visitor->var_defs[i];
    if (strcmp(vardef->var_def_var_name, node->var_name) == 0) {
      return visitor_visit(visitor, vardef->var_def_value);
    }
  }
  printf(RED "ERR " YEL "undefined identifier '%s'\n", node->var_name);
}
/*Tells the visitor to interpret a function call and execute it*/
AST *visitor_visit_func_call(Visitor *visitor, AST *node) {
  if (strcmp(node->func_call_name, "write") == 0) {
    return std_func_write(visitor, node->func_call_args,
                          node->func_call_args_size);
  } else if (strcmp(node->func_call_name, "read") == 0) {
    return std_func_read(visitor, node->func_call_args,
                         node->func_call_args_size);
  }
  printf(RED "ERR " YEL "undefined method %s\n", node->func_call_name);
  exit(1);
}
/*Tells the visitor to interpret a string AST node*/
AST *visitor_visit_str(Visitor *visitor, AST *node) { return node; }
/*Tells the visitor to begin the recursive process of interpreting the root
 * syntax tree*/
AST *visitor_visit_compound(Visitor *visitor, AST *node) {
  for (int i = 0; i < node->compound_size; i++) {
    visitor_visit(visitor, node->compound_value[i]);
  }
  return ast_init(AST_NOOP);
}