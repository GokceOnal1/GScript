#include "AST.h"

/*Constructs an AST node with type TYPE (sets initial values to NULL)*/
AST* ast_init(int type) {
	AST* ast = calloc(1, sizeof(AST));
	
	ast->type = type;
	ast->var_def_var_name = (void*)0;
	ast->var_def_value = (void*)0;
	ast->func_def_body = (void*)0;
	ast->var_name = (void*)0;
	ast->func_call_name = (void*)0;
	ast->func_call_args = (void*)0;
	ast->func_call_args_size = 0;
	ast->str_value = (void*)0;
	ast->compound_value = (void*)0;
	ast->compound_size = 0;
	
	return ast;
}