#include "io.h"
#include <stdio.h>
#include <stdlib.h>

char* get_file_data(const char* filepath) {
	char* buffer = 0;
	long length;
	FILE* file = fopen(filepath, "rb");
	if(file) {
		fseek(file, 0, SEEK_END);
		length = ftell(file);
		fseek(file, 0, SEEK_SET);

		buffer = calloc(length, length);

		if(buffer) {
			fread(buffer, 1, length, file);
		}
		fclose(file);
		return buffer;
	}
	printf("ERR::INTERNAL failed file read");
	exit(2);
}